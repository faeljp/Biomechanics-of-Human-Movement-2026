clear; clc; close all;

%% ===================== FILES =====================
files = { ...
    'Walkfast1.mat', ...
    'WalkfastCoCon1.mat', ...
    'WalkSlow1.mat', ...
    'WalkSlowCoCon1.mat'};

condNames = { ...
    'Fast - No CoCon', ...
    'Fast - CoCon', ...
    'Slow - No CoCon', ...
    'Slow - CoCon'};

mvcFile = 'MVC.mat';

%% ===================== SETTINGS =====================
fs_emg = 2048;          % sampling frequency from your files
nCyclesToUse = 10;      % requested in assignment
nNorm = 101;            % 0-100% gait cycle

% EMG processing parameters
bp_low = 20;            % band-pass lower cutoff (Hz)
bp_high = 450;          % band-pass upper cutoff (Hz)
lp_env = 6;             % low-pass cutoff for linear envelope (Hz)

% Heel-strike detection
grfThresh = 0.05;       % threshold for left vertical GRF
minStrideTime = 0.8;    % minimum time between heel strikes (s)

% Target muscles according to EMGLabels.txt
% EMG1 = Rectus Femoris
% EMG4 = Semitendinosus
% EMG6 = Tibialis Anterior
% EMG9 = Soleus
muscleNames = {'Tibialis Anterior','Soleus','Rectus Femoris','Semitendinosus'};
emgChannels = [6 9 1 4];   % in the order above

%% ===================== LOAD MVC =====================
mvcStruct = load(mvcFile);
mvcField = fieldnames(mvcStruct);
mvcData = mvcStruct.(mvcField{1});

analogLabels_mvc = string(mvcData.Analog.Labels);
analogData_mvc = mvcData.Analog.Data;

% Compute MVC reference for required muscles
mvcVals = zeros(1,length(emgChannels));

for m = 1:length(emgChannels)
    chLabel = sprintf('EMG%d', emgChannels(m));
    idx = find(analogLabels_mvc == chLabel);

    raw = analogData_mvc(idx,:);
    env = emg_to_activation(raw, fs_emg, bp_low, bp_high, lp_env);

    % use max envelope value as MVC reference
    mvcVals(m) = max(env);

    if mvcVals(m) == 0
        error('MVC value for %s is zero. Check MVC file.', muscleNames{m});
    end
end

%% ===================== PROCESS ALL CONDITIONS =====================
allMean = cell(length(files),1);
allStd  = cell(length(files),1);
gaitPct = linspace(0,100,nNorm);

for f = 1:length(files)

    S = load(files{f});
    topField = fieldnames(S);
    D = S.(topField{1});

    analogLabels = string(D.Analog.Labels);
    analogData = D.Analog.Data;

    % -------- Left vertical GRF --------
    % labels: Lz1 Lz2 Lz3 Lz4
    idxLz = find(ismember(analogLabels, ["Lz1","Lz2","Lz3","Lz4"]));
    if isempty(idxLz)
        error('Could not find Lz1-Lz4 in %s', files{f});
    end

    leftFz = sum(analogData(idxLz,:),1);

    % Depending on sign convention, vertical load may be negative
    % Make stance positive for thresholding
    if abs(min(leftFz)) > abs(max(leftFz))
        leftFz_use = -leftFz;
    else
        leftFz_use = leftFz;
    end

    hs = detect_heel_strikes(leftFz_use, fs_emg, grfThresh, minStrideTime);

    if length(hs) < nCyclesToUse + 1
        error('%s does not contain enough left heel-strikes for %d gait cycles.', ...
            files{f}, nCyclesToUse);
    end

    % Use first 10 full gait cycles
    hs = hs(1:nCyclesToUse+1);

    % Store normalized cycles: [nNorm x nCycles x nMuscles]
    normCycles = zeros(nNorm, nCyclesToUse, length(emgChannels));

    for m = 1:length(emgChannels)

        chLabel = sprintf('EMG%d', emgChannels(m));
        idx = find(analogLabels == chLabel);

        if isempty(idx)
            error('Could not find %s in %s', chLabel, files{f});
        end

        raw = analogData(idx,:);
        env = emg_to_activation(raw, fs_emg, bp_low, bp_high, lp_env);

        % MVC normalization
        act = env / mvcVals(m);

        % Optional clipping
        act(act < 0) = 0;
        % act(act > 1) = 1;   % uncomment if you want to cap at 1

        for c = 1:nCyclesToUse
            seg = act(hs(c):hs(c+1));
            x_old = linspace(0,100,length(seg));
            x_new = linspace(0,100,nNorm);

            normCycles(:,c,m) = spline(x_old, seg, x_new);
        end
    end

    allMean{f} = mean(normCycles, 2);   % [nNorm x nMuscles]
    allStd{f}  = std(normCycles, 0, 2); % [nNorm x nMuscles]
end

%% ===================== PLOT (improved) =====================
figure('Color','w','Position',[100 100 1200 900]);

tiledlayout(2,2,'TileSpacing','compact','Padding','compact');

% line colors
cols = [
    0.0000 0.4470 0.7410   % blue
    0.8500 0.3250 0.0980   % orange
    0.9290 0.6940 0.1250   % yellow
    0.4940 0.1840 0.5560   % purple
];

for m = 1:length(muscleNames)
    nexttile; hold on;

    h = gobjects(length(files),1);

    for f = 1:length(files)
        mu = allMean{f}(:,m);
        sd = allStd{f}(:,m);

        c = cols(f,:);

        % shaded SD with same color as line
        fill([gaitPct fliplr(gaitPct)], ...
             [(mu+sd)' fliplr((mu-sd)')], ...
             c, 'FaceAlpha', 0.15, 'EdgeColor', 'none');

        h(f) = plot(gaitPct, mu, 'Color', c, 'LineWidth', 2);
    end

    xlabel('Gait cycle (%)');
    ylabel('Muscle activation');
    title(muscleNames{m});
    xlim([0 100]);
    grid on;
end

lgd = legend(h, condNames, 'Orientation', 'horizontal');
lgd.Layout.Tile = 'south';

sgtitle('Mean \pm SD of muscle activations over 10 gait cycles');
%% ===================== FUNCTIONS =====================

function env = emg_to_activation(raw, fs, bp_low, bp_high, lp_env)
    % Remove DC
    raw = raw - mean(raw);

    % Band-pass filter
    [b_bp, a_bp] = butter(4, [bp_low bp_high]/(fs/2), 'bandpass');
    emg_bp = filtfilt(b_bp, a_bp, raw);

    % Full-wave rectification
    emg_rect = abs(emg_bp);

    % Low-pass filter to get linear envelope
    [b_lp, a_lp] = butter(4, lp_env/(fs/2), 'low');
    env = filtfilt(b_lp, a_lp, emg_rect);
end

function hs = detect_heel_strikes(leftFz, fs, thresh, minStrideTime)
    % Contact when force > threshold
    contact = leftFz > thresh;

    % Heel-strike = transition from swing(0) to stance(1)
    hs_all = find(diff(contact) == 1) + 1;

    % Enforce a minimum interval between heel strikes
    minSamples = round(minStrideTime * fs);
    hs = [];

    for i = 1:length(hs_all)
        if isempty(hs) || (hs_all(i) - hs(end) > minSamples)
            hs = [hs hs_all(i)];
        end
    end
end
%% ===================== SUMMARY VALUES IN COMMAND WINDOW =====================

shortNames = {'TA','SOL','RF','ST'};

for f = 1:length(files)
    fprintf('\n===== %s =====\n', condNames{f});
    for m = 1:length(shortNames)
        mean_over_cycle = mean(allMean{f}(:,m));
        mean_sd_over_cycle = mean(allStd{f}(:,m));

        fprintf('%s: mean = %.4f, mean SD = %.4f\n', ...
            shortNames{m}, mean_over_cycle, mean_sd_over_cycle);
    end
end