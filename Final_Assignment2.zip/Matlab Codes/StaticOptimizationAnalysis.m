clear; clc; close all;

clear; clc; close all;

%% ===================== FILES =====================
soFiles = { ...
    'C:\Users\faelj\Coding\Biomechanics of Human Movement\Assignment2\Assignment#2Data-4\Walkfast\Final_walkfast_NoCo_StaticOptimization_activation.sto', ...
    'C:\Users\faelj\Coding\Biomechanics of Human Movement\Assignment2\Assignment#2Data-4\WalkfastCoCo\Final_SO_WalkfastCoCo_StaticOptimization_activation.sto', ...
    'C:\Users\faelj\Coding\Biomechanics of Human Movement\Assignment2\Assignment#2Data-4\WalkSlow\Final_walkslow_noco_StaticOptimization_activation.sto', ...
    'C:\Users\faelj\Coding\Biomechanics of Human Movement\Assignment2\Assignment#2Data-4\WalkSlowCoCon\Final_walkslow_coco_StaticOptimization_activation.sto'};

grfFiles = { ...
    'C:\Users\faelj\Coding\Biomechanics of Human Movement\Assignment2\Assignment#2Data-4\Walkfast\Walkfast1.mot', ...
    'C:\Users\faelj\Coding\Biomechanics of Human Movement\Assignment2\Assignment#2Data-4\WalkfastCoCo\WalkfastCoCon_ext.mot', ...
    'C:\Users\faelj\Coding\Biomechanics of Human Movement\Assignment2\Assignment#2Data-4\WalkSlow\WalkSlow_forces.mot', ...
    'C:\Users\faelj\Coding\Biomechanics of Human Movement\Assignment2\Assignment#2Data-4\WalkSlowCoCon\WalkSlowCoCon1.mot'};

condNames = { ...
    'Fast - No CoCon', ...
    'Fast - CoCon', ...
    'Slow - No CoCon', ...
    'Slow - CoCon'};

%% ===================== RESERVE ACTUATORS =====================

reserveLabels = [
    "hip_flexion_l_reserve"
    "knee_angle_l_reserve"
    "ankle_angle_l_reserve"
];

reserveNames = {'Hip Flexion','Knee','Ankle'};

%% ===================== SETTINGS =====================
nCyclesToUse = 10;
nNorm = 101;

grfThresh = 100;        % Newtons (ajuste se necessário)
minStrideTime = 0.8;

% músculos do OpenSim (lado esquerdo)
muscleLabels = [
    "tib_ant_l"
    "soleus_l"
    "rect_fem_l"
    "semiten_l"
];

muscleNames = {'Tibialis Anterior','Soleus','Rectus Femoris','Semitendinosus'};

%% ===================== PROCESS =====================
allMean = cell(length(soFiles),1);
allStd  = cell(length(soFiles),1);
allReserveMean = cell(length(soFiles),1); % <- ADICIONAR ISSO
allReserveStd  = cell(length(soFiles),1); % <- ADICIONAR ISSO

gaitPct = linspace(0,100,nNorm);

allReserve = cell(length(soFiles),1);
allTime = cell(length(soFiles),1);

for f = 1:length(soFiles)

    %% ===== LOAD STATIC OPTIMIZATION =====
    so = importdata(soFiles{f});
    time = so.data(:,1);
    labels = string(so.colheaders);
    values = so.data;

    %% ===== EXTRACT RESERVE ACTUATORS =====
    
    reserveData = zeros(length(time), length(reserveLabels));
    
    for r = 1:length(reserveLabels)
        idx = find(labels == reserveLabels(r));
    
        if isempty(idx)
            error('Reserve actuator %s not found in %s', reserveLabels(r), soFiles{f});
        end
    
        reserveData(:,r) = values(:, idx);
    end
    
    allReserve{f} = reserveData;
    allTime{f} = time;

    fs = 1 / mean(diff(time));

    %% ===== LOAD GRF =====
    grf = importdata(grfFiles{f});
    grf_labels = string(grf.colheaders);
    grf_data = grf.data;
    grf_time = grf.data(:,1);     % tempo do GRF

    % procurar força vertical esquerda (geralmente ground_force_vy)
    idxFz = find(contains(lower(grf_labels), 'ground_force2_vy'));
    
    if isempty(idxFz)
        error('Left vertical GRF not found in %s', grfFiles{f});
    end
    
    leftFz_raw = grf_data(:, idxFz);

    leftFz = interp1(grf_time, leftFz_raw, time, 'linear', 'extrap');

    % garantir positivo em stance
    if abs(min(leftFz)) > abs(max(leftFz))
        leftFz = -leftFz;
    end

    %% ===== DETECT HEEL STRIKES =====
    hs = detect_heel_strikes(leftFz, fs, grfThresh, minStrideTime);
    disp(length(hs))
    if length(hs) > nCyclesToUse + 1
        hs = hs(1:nCyclesToUse+1);
    end

    %% ===== PROCESS MUSCLES =====
    normCycles = zeros(nNorm, length(hs)-1, length(muscleLabels));
    normReserve = zeros(nNorm, length(hs)-1, length(reserveLabels));

    for m = 1:length(muscleLabels)

        idx = find(labels == muscleLabels(m));

        if isempty(idx)
            error('Muscle %s not found in %s', muscleLabels(m), soFiles{f});
        end

        act = values(:, idx);

        % garantir limites físicos
        act(act < 0) = 0;
        act(act > 1) = 1;

        for c = 1:length(hs)-1

            seg = act(hs(c):hs(c+1));

            x_old = linspace(0,100,length(seg));
            x_new = linspace(0,100,nNorm);

            normCycles(:,c,m) = spline(x_old, seg, x_new);
        end
    end

 %% ===== PROCESS RESERVE ACTUATORS =====

    for r = 1:length(reserveLabels)
    
        idx = find(labels == reserveLabels(r));
    
        if isempty(idx)
            error('Reserve actuator %s not found in %s', reserveLabels(r), soFiles{f});
        end
    
        act = values(:, idx);
    
        for c = 1:length(hs)-1
    
            seg = act(hs(c):hs(c+1));
    
            x_old = linspace(0,100,length(seg));
            x_new = linspace(0,100,nNorm);
    
            normReserve(:,c,r) = spline(x_old, seg, x_new);
        end
    end
    
    allReserveMean{f} = mean(normReserve, 2);
    allReserveStd{f}  = std(normReserve, 0, 2);

    allMean{f} = mean(normCycles, 2);
    allStd{f}  = std(normCycles, 0, 2);
end

%% ===================== PLOT =====================
figure('Color','w','Position',[100 100 1200 900]);

tiledlayout(2,2,'TileSpacing','compact','Padding','compact');

cols = [
    0.0000 0.4470 0.7410
    0.8500 0.3250 0.0980
    0.9290 0.6940 0.1250
    0.4940 0.1840 0.5560
];

for m = 1:length(muscleNames)

    nexttile; hold on;
    h = gobjects(length(soFiles),1);

    for f = 1:length(soFiles)

        mu = allMean{f}(:,m);
        sd = allStd{f}(:,m);
        c = cols(f,:);

        fill([gaitPct fliplr(gaitPct)], ...
             [(mu+sd)' fliplr((mu-sd)')], ...
             c, 'FaceAlpha', 0.15, 'EdgeColor', 'none');

        h(f) = plot(gaitPct, mu, 'Color', c, 'LineWidth', 2);
    end

    xlabel('Gait cycle (%)');
    ylabel('Muscle activation');
    title(muscleNames{m});
    xlim([0 100]);
    grid on;
    
end

lgd = legend(h, condNames, 'Orientation', 'horizontal');
lgd.Layout.Tile = 'south';

sgtitle('Static Optimization: Mean \pm SD over 10 gait cycles');

%% ===================== RESERVE ACTUATORS (GAIT CYCLE) =====================

figure('Color','w','Position',[150 150 1200 900]);

tiledlayout(1,length(reserveLabels),'TileSpacing','compact','Padding','compact');

for r = 1:length(reserveNames)

    nexttile; hold on;

    h = gobjects(length(soFiles),1);

    for f = 1:length(soFiles)

        mu = allReserveMean{f}(:,r);
        sd = allReserveStd{f}(:,r);
        c = cols(f,:);

        fill([gaitPct fliplr(gaitPct)], ...
             [(mu+sd)' fliplr((mu-sd)')], ...
             c, 'FaceAlpha', 0.15, 'EdgeColor', 'none');

        h(f) = plot(gaitPct, mu, 'Color', c, 'LineWidth', 2);
    end

    xlabel('Gait cycle (%)');
    ylabel('Reserve actuator');
    title(reserveNames{r});
    xlim([0 100]);
    grid on;
end

lgd = legend(h, condNames, 'Orientation', 'horizontal');
lgd.Layout.Tile = 'south';

sgtitle('Reserve actuator mean \pm SD over gait cycle');

%% ===================== FUNCTIONS =====================

function hs = detect_heel_strikes(Fz, fs, thresh, minStrideTime)

    contact = Fz > thresh;

    hs_all = find(diff(contact) == 1) + 1;

    minSamples = round(minStrideTime * fs);
    hs = [];

    for i = 1:length(hs_all)
        if isempty(hs) || (hs_all(i) - hs(end) > minSamples)
            hs = [hs hs_all(i)];
        end
    end
end

%% ===================== SUMMARY =====================
shortNames = {'TA','SOL','RF','ST'};

for f = 1:length(soFiles)
    fprintf('\n===== %s =====\n', condNames{f});
    for m = 1:length(shortNames)

        mean_over_cycle = mean(allMean{f}(:,m));
        mean_sd_over_cycle = mean(allStd{f}(:,m));

        fprintf('%s: mean = %.4f, mean SD = %.4f\n', ...
            shortNames{m}, mean_over_cycle, mean_sd_over_cycle);
    end
end