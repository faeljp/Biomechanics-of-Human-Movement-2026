import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.signal import find_peaks
from scipy.interpolate import interp1d

# ============================================================
# 1. FUNCTION TO READ .STO FILES
# ============================================================
def read_sto(filepath):
    """Read an OpenSim .sto file, skip header, return DataFrame."""
    with open(filepath, 'r') as f:
        lines = f.readlines()
    # Find 'endheader'
    header_end = 0
    for i, line in enumerate(lines):
        if 'endheader' in line:
            header_end = i + 1
            break
    # Read column names and data
    col_line = lines[header_end].strip().replace('\r', '')
    columns = col_line.split('\t')
    data_lines = lines[header_end + 1:]
    data = []
    for line in data_lines:
        vals = line.strip().replace('\r', '').split('\t')
        data.append([float(v) for v in vals])
    df = pd.DataFrame(data, columns=columns)
    return df

# ============================================================
# 2. LOAD ALL FILES
# ============================================================
# Tendon Length
tl_fast = read_sto('/mnt/user-data/uploads/3DGaitModel2392_scaled_MuscleAnalysis_TendonLength.sto')
tl_slow = read_sto('/mnt/user-data/uploads/3DGaitModel2392_scaled_MuscleAnalysis_TendonLength_slow.sto')

# Moment Arm (ankle)
ma_fast = read_sto('/mnt/user-data/uploads/3DGaitModel2392_scaled_MuscleAnalysis_MomentArm_ankle_angle_r_fast.sto')
ma_slow = read_sto('/mnt/user-data/uploads/3DGaitModel2392_scaled_MuscleAnalysis_MomentArm_ankle_angle_r.sto')

muscles = ['tib_ant_r', 'soleus_r']
muscle_labels = ['Tibialis Anterior', 'Soleus']

# ============================================================
# 3. DETECT GAIT CYCLES & NORMALIZE
# ============================================================
def detect_gait_cycles(df, signal_col='soleus_r', n_points=101):
    """
    Detect gait cycles using peaks of a periodic muscle signal.
    Returns list of normalized cycles (0-100%) with n_points each.
    """
    time = df['time'].values
    signal = df[signal_col].values
    
    # Estimate period from sampling rate (typical gait ~1-1.5s)
    dt = np.median(np.diff(time))
    # Use soleus tendon length peaks (max dorsiflexion ~ heel strike region)
    min_distance = int(0.6 / dt)  # at least 0.6s between cycles
    
    peaks, _ = find_peaks(signal, distance=min_distance, prominence=0.001)
    
    # If not enough peaks, try with the negative signal (troughs)
    if len(peaks) < 3:
        peaks, _ = find_peaks(-signal, distance=min_distance, prominence=0.001)
    
    return peaks, time

def normalize_cycles(df, peaks, columns, n_points=101):
    """
    Given detected cycle boundaries (peaks), interpolate each cycle
    to n_points (0-100% gait cycle). Returns dict of arrays per column.
    """
    time = df['time'].values
    results = {col: [] for col in columns}
    
    gait_pct = np.linspace(0, 100, n_points)
    
    for i in range(len(peaks) - 1):
        start_idx = peaks[i]
        end_idx = peaks[i + 1]
        
        t_cycle = time[start_idx:end_idx + 1]
        # Normalize time to 0-100%
        t_norm = (t_cycle - t_cycle[0]) / (t_cycle[-1] - t_cycle[0]) * 100
        
        for col in columns:
            signal = df[col].values[start_idx:end_idx + 1]
            interp_func = interp1d(t_norm, signal, kind='cubic', fill_value='extrapolate')
            results[col].append(interp_func(gait_pct))
    
    # Convert to arrays
    for col in columns:
        results[col] = np.array(results[col])
    
    return results, gait_pct

# Process all datasets
datasets = {
    'tl_fast': tl_fast,
    'tl_slow': tl_slow,
    'ma_fast': ma_fast,
    'ma_slow': ma_slow,
}

# Use soleus_r for gait cycle detection in tendon length files,
# tib_ant_r for moment arm files (larger signal)
detect_cols = {
    'tl_fast': 'soleus_r',
    'tl_slow': 'soleus_r',
    'ma_fast': 'tib_ant_r',
    'ma_slow': 'tib_ant_r',
}

all_results = {}
n_cycles_info = {}

for key, df in datasets.items():
    det_col = detect_cols[key]
    peaks, time = detect_gait_cycles(df, signal_col=det_col)
    
    # Use up to 10 cycles (as per exercise instructions)
    max_cycles = min(len(peaks) - 1, 10)
    peaks_used = peaks[:max_cycles + 1]
    
    results, gait_pct = normalize_cycles(df, peaks_used, muscles)
    all_results[key] = results
    n_cycles_info[key] = max_cycles
    print(f"{key}: detected {len(peaks)-1} cycles, using {max_cycles}")

# ============================================================
# 4. COMPUTE MEAN & STD
# ============================================================
stats = {}
for key in all_results:
    stats[key] = {}
    for muscle in muscles:
        data = all_results[key][muscle]
        stats[key][muscle] = {
            'mean': np.mean(data, axis=0),
            'std': np.std(data, axis=0),
        }

# ============================================================
# 5. PLOT: 2x2 grid (rows=muscles, cols=measures)
# ============================================================
fig, axes = plt.subplots(2, 2, figsize=(14, 9))

colors_fast = '#e74c3c'   # red
colors_slow = '#2980b9'   # blue

measure_keys = [('tl_fast', 'tl_slow'), ('ma_fast', 'ma_slow')]
measure_titles = ['Tendon Length (m)', 'Moment Arm (m)']

for col_idx, ((key_fast, key_slow), ylabel) in enumerate(zip(measure_keys, measure_titles)):
    for row_idx, (muscle, label) in enumerate(zip(muscles, muscle_labels)):
        ax = axes[row_idx, col_idx]
        
        # Fast walk
        mean_f = stats[key_fast][muscle]['mean']
        std_f = stats[key_fast][muscle]['std']
        ax.plot(gait_pct, mean_f, color=colors_fast, linewidth=2, label='Fast Walk')
        ax.fill_between(gait_pct, mean_f - std_f, mean_f + std_f,
                        color=colors_fast, alpha=0.2)
        
        # Slow walk
        mean_s = stats[key_slow][muscle]['mean']
        std_s = stats[key_slow][muscle]['std']
        ax.plot(gait_pct, mean_s, color=colors_slow, linewidth=2, label='Slow Walk')
        ax.fill_between(gait_pct, mean_s - std_s, mean_s + std_s,
                        color=colors_slow, alpha=0.2)
        
        ax.set_title(f'{label}', fontsize=13, fontweight='bold')
        ax.set_xlabel('Gait Cycle (%)')
        ax.set_ylabel(ylabel)
        ax.set_xlim(0, 100)
        ax.legend(loc='best', fontsize=9)
        ax.grid(True, linestyle='--', alpha=0.4)

fig.suptitle('Tendon Length & Moment Arm: Fast Walk vs Slow Walk\n'
             '(Mean ± SD across 10 gait cycles)',
             fontsize=15, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/claude/tendon_momentarm_comparison.png', dpi=150, bbox_inches='tight')
plt.close()
print("\nPlot saved!")
